import React, { useState } from 'react';
import { DarkModeProvider } from './component/Darkmode';
import About from './pages/About';
import Hero from './sections/Hero';
import Services from './component/Services';
import Map from './component/Map';
import Form from './component/Form';
import ContactInfo from './component/ContactInfo';
import Header from './component/Header';
import Footer from './component/Footer';
import './component/about.css'

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');
  

  return (
    <DarkModeProvider>
      <Header setCurrentPage={setCurrentPage} />
      
      {currentPage === 'home' && (
        <>
          <Hero />
          <Services />
          <Map />
          <Form />
          <ContactInfo />
        </>
      )}
      
      {currentPage === 'about' && <About goHome={() => setCurrentPage('home')} />}
        {currentPage === 'services' && <Services goHome={() => setCurrentPage('home')} />}
      {currentPage === 'ContactInfo' && <Contact goHome={() => setCurrentPage('home')} />}
        {currentPage === 'blog' && <Blog goHome={() => setCurrentPage('home')} />}
      
      <Footer />
    </DarkModeProvider>
  );
};

export default App;