 

import React from "react";
import { 
  FaBuilding, 
  FaChalkboardTeacher, 
  FaCheckCircle, 
  FaShieldAlt, 
  FaHandshake, 
  FaUsers,
  FaSearch,
  FaGraduationCap
} from "react-icons/fa";
import "./services.css";

const Services = () => {
  const OpenHTMLPage=()=>{
    window.location.href =' /DEPI-Project/P_Mohamed%20Hany/pages/index.html'
  };
    const OpenSecondHTMLPage=()=>{
    window.location.href =' /DEPI-Project/P_Mohamed%20Hany/pages/study.html'
  };
  return (
    <div className="services-page">
      {/* Hero Section */}
      <section className="services-hero">
        <div className="hero-content">
          <h1>Empowering Students with Housing & Knowledge Exchange</h1>
          <p>
            SwapLearn helps university students find safe, affordable housing while 
            facilitating knowledge sharing between peers.
          </p>
        </div>
      </section>

      {/* Main Services Cards */}
      <section className="main-services">
        <div className="services-container">
          <h2>Our Core Services</h2>
          <div className="service-cards">
            <div className="service-card">
              <div className="service-icon">
                <FaBuilding />
              </div>
              <h3>Student Housing</h3>
              <p>
                Find verified student accommodations near your university with our 
                trusted network of landlords and property managers.
              </p>
              <button className="service-btn" onClick={OpenHTMLPage} >Explore Housing</button>
            </div>

            <div className="service-card highlight">
              <div className="service-icon">
                <FaChalkboardTeacher />
              </div>
              <h3>Knowledge Exchange</h3>
              <p>
                Share your skills and learn from other students through our 
                innovative peer-to-peer learning platform.
              </p>
              <button className="service-btn" onClick={OpenSecondHTMLPage}>Start Learning</button>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="why-choose-us">
        <div className="container">
          <h2>Why Choose SwapLearn?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <FaCheckCircle />
              </div>
              <h4>Verified Listings</h4>
              <p>All housing options are carefully vetted for your safety.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <FaShieldAlt />
              </div>
              <h4>Secure Platform</h4>
              <p>Your data and transactions are always protected.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <FaHandshake />
              </div>
              <h4>Community Driven</h4>
              <p>Built by students, for students.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <FaUsers />
              </div>
              <h4>24/7 Support</h4>
              <p>Our team is always ready to help you.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon blue-icon">
                <FaSearch />
              </div>
              <h4>Advanced Search</h4>
              <p>Powerful filters to find exactly what you need.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon purple-icon">
                <FaGraduationCap />
              </div>
              <h4>Learning Certificates</h4>
              <p>Get recognition for your knowledge sharing.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;